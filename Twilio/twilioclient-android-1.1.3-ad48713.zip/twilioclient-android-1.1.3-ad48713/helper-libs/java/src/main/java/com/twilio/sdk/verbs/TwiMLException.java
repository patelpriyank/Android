package com.twilio.sdk.verbs;

// TODO: Auto-generated Javadoc
/**
 * The Class TwiMLException.
 */
public class TwiMLException extends Exception {

    /**
     * Instantiates a new twi ml exception.
     *
     * @param arg0 the arg0
     */
    public TwiMLException(String arg0) {
        super(arg0);
    }

}
